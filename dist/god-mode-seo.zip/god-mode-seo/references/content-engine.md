# content-engine: brief, article, published

## Steps
1. **Check the keyword.** `keyword_research` for volume, difficulty and related searches. Check `list_articles` and `search_console_performance`: if a page already targets or ranks for it, recommend on-page-fixer for that page instead and stop unless the user insists.
2. **Read what ranks.** Web search the keyword and read the top 5. Let the results decide the format: lists rank, write a list; comparisons rank, write a comparison. A named product or brand in the keyword means a listicle or comparison.
3. **Brief.** Title, the answer-first paragraph, H2s that match the questions searchers ask, what you will add that the top results lack (a worked example, real numbers from the business, a clear recommendation), internal links to the content pillar and 2 to 4 related published articles. If it is a planned Distribb article, read `get_article_brief` for the exchange partner links it must carry.
4. **Write.** Full HTML, answer first, specific, short paragraphs, a table where things are compared. No invented statistics, quotes, reviews or prices: leave out anything you cannot source.
5. **Save.** Show the title, meta description and first paragraph, then on yes `create_article` with `keyword`, `title`, `content`, `meta_description` and the `scheduled_date` the user picks. Content of 2,000+ characters is published exactly as sent. To publish right away, `publish_article` after a second yes.
   Or let Distribb write it: `create_article` with only the keyword and a date, and Distribb writes and publishes it on that date.

## Output
- The brief (short), then the article preview, then the saved article and its scheduled date or live URL.
