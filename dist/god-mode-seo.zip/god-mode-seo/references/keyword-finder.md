# keyword-finder: volume, difficulty and fit

## Steps
1. Read `get_project`: business description, target audience, content pillars, location. Pick 3 to 5 seed keywords from what the business sells (ask the user to confirm them in one line).
2. Call `keyword_research` for each seed with `limit: 30`.
3. Add the queries the site already almost ranks for: from `search_console_performance` (`days: 28, limit: 100`), queries at position 4 to 20 with 10 or more impressions.
4. Remove duplicates. For each candidate, check coverage with `list_articles` (status Published and Planned): does a page or planned article already target it?
5. Label intent and fit for each keyword, buying intent first: comparisons ("x vs y", "alternatives to x"), "best x for y", pricing, "near me", service and problem searches. Pure "what is" topics only when they support a cluster.
6. Score: fit (high 3, medium 2, low 1) x search volume / (keyword difficulty + 10). Show the formula.

## Output
- One sentence: the best 3 opportunities and why.
- Table (top 15): keyword | volume | difficulty | CPC | intent | fit | existing page | action (new page, or optimize the existing one).
- Next actions: cluster-builder to group them, content-engine to write the first one, on-page-fixer for the ones you already rank for.
