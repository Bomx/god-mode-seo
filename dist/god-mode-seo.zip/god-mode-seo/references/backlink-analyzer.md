# backlink-analyzer: the links worth copying

## Steps
1. Call `backlinks_status` (credits, links received, verified, exchange participation) and `list_backlinks` (every verified link: source URL, target URL).
2. Group received links by target page and by source domain. Note which kinds of pages earn links (listicles, statistics pages, guides, tools, the homepage), using the page titles from `list_articles` where they are Distribb articles.
3. Find the pages that need links: from `search_console_performance` (`days: 28, limit: 100`) take pages at position 5 to 20 with the most impressions, and mark the ones with zero or one received link.
4. Check the exchange: if `network_participation` is No, explain that joining the backlink exchange (`update_project` with `backlinks_network: true`) makes every article carry links to partner businesses and earns links back. Turn it on only after the user says yes.

## Output
- One sentence: what earns links on this site and which pages need them most.
- Table: page needing links | position | impressions | links now | best link type to get.
- The pattern worth copying (for example "statistics pages earned 40% of links: publish one per pillar").
- Next actions: content-engine for a link-worthy page, internal-linker to pass existing authority, the exchange switch.
