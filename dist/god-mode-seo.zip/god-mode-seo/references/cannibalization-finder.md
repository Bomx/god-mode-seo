# cannibalization-finder: pages fighting for one search

## Steps
1. Call `list_optimizations` (`limit: 25`) and keep suggestions with `opportunity_type: cannibalisation` that are not rejected. For each, `get_optimization` gives the query, the competing pages with their Search Console data, and the page Distribb picked to win. Advisory rows carry no rewrite: you fix those yourself. Ignore conflicts about search operators (queries starting with `site:` and similar).
2. Add likely conflicts Distribb has not flagged: articles in `list_articles` (MainKeyword, Title) with the same or nearly the same main keyword. On big sites, check the keywords behind the site's top non-brand queries first rather than every article. Fetch each losing URL: if it already redirects to the winner, it is fixed; drop it. Treat the rest as "to check", not proven.
3. For each conflict, choose the winner by clicks and position from `search_console_performance` (`days: 28, limit: 100`; a page missing from that list has fewer clicks than every page in it), then by which page matches the search intent.
4. Pick the fix for each loser:
   - **Same intent, weaker page:** merge its useful parts into the winner, then a 301 redirect from loser to winner. Give the exact rule for their CMS (`get_project`, `setup.website.platform`); when it is unknown, ask, or give the WordPress, Shopify and Webflow versions.
   - **Different intent possible:** re-angle the loser to its own search (new title, H1 and intro).
   - **Both needed:** keep both, link loser to winner with the query as anchor, and remove the query from the loser's title.
5. On yes, apply the edits you showed with `update_article`, or Distribb's re-angle when it passes the stale-rewrite check.

## Output
- Table: search | winner | loser(s) | fix.
- The exact redirect rules or edits.
