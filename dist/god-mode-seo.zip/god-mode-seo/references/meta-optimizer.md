# meta-optimizer: titles that earn the click

## Steps
1. Get the page: the URL the user gives, or the 3 pages with the most impressions that rank in the top 10 and fall under your CTR benchmark (cheat sheet) from `search_console_performance` (`days: 28, limit: 100`).
2. Find its searches: the `top_queries` of any optimization for that page in `list_optimizations`, otherwise the site's top queries that match the page's topic.
3. Read the current title and meta: from `list_articles` (Title, MetaDescription) when it is a Distribb article, otherwise fetch the page.
4. Write 3 variants:
   - **A, query first:** the main search, word for word, at the start.
   - **B, benefit:** what the reader gets, with a number only if it is on the page.
   - **C, answer:** the question the searcher has, and a promise the page keeps.
   Titles 60 characters or fewer, meta descriptions 140 to 155 characters, nothing the page does not deliver.
5. On the user's pick and yes: for a Distribb article, `update_article` with `{title, meta_description, sync: true}`; otherwise give the exact copy to paste in their CMS or SEO plugin.

## Output
- Table: variant | title | characters | meta description.
- Your pick and why, in one line.
- Next action: run kpi-monitor in 14 days to see if the CTR moved.
