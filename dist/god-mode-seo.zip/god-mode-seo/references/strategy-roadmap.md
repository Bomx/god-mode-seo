# strategy-roadmap: quick wins to long term

## Steps
1. Gather (keep it to these calls): `get_project`; `search_console_performance` with `days: 28` and `56`; `list_optimizations` (pending and ready); `keyword_research` on the main service; `backlinks_status`; `ai_visibility_report` summary.
2. Find the wins:
   - **This week:** optimizations already ready to publish, striking-distance pages (position 4 to 20 with impressions), low-CTR titles (your CTR benchmark).
   - **This quarter:** clusters to build around the money pages, decaying posts to refresh, cannibalization to fix, prompts where AI cites rivals instead.
   - **Long term:** authority (the backlink exchange, getting onto the "best x" roundups AI reads, a statistics page per pillar), technical health.
3. For each item: the data that justifies it, the skill to run, effort (S, M, L).

## Output
- One sentence: the one thing to do first and why.
- Three tables (this week, this quarter, long term): action | why (data) | skill | effort. 12 items at most in total.
