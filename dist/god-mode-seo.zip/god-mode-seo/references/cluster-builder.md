# cluster-builder: a pillar and its supporting posts

## Steps
1. Pick the pillar: a service from `get_project` (content pillars, business description) or the user's topic.
2. `keyword_research` on the pillar seed with `limit: 50`, plus 2 related seeds.
3. Group the keywords by intent: one pillar page (the broad money search) and 8 to 12 supporting posts (comparisons, best-x-for-y, problems, how-tos that lead to the service). Buying intent first.
4. Check coverage with `list_articles` (Published and Planned): mark what exists, what to optimize, what is missing.
5. The link plan: every supporting post links to the pillar with the pillar's main search as anchor; the pillar links to each supporting post; siblings link where the reader needs it.
6. On yes, schedule the missing posts with `create_article` (keyword, title, `scheduled_date` spread over the weeks the user picks). Without content Distribb writes each one on its date.

## Output
- The cluster map: pillar, then each supporting post with keyword | volume | difficulty | status (exists, optimize, missing).
- The link plan.
- The schedule you created, when you created one.
