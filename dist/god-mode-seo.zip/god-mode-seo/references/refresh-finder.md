# refresh-finder: posts losing clicks, and the fix

## Steps
1. List Distribb's `declining_page` optimizations from `list_optimizations` with their `signals` (impressions and position before and after).
2. Add your own: the previous-period calculation (cheat sheet) on `search_console_performance` with `days: 28` and `56`, limited to article URLs (from `list_articles`, status Published). A post is decaying when it lost 30% or more of its clicks or slid 2 or more positions.
3. For the top 5 by clicks lost, read the post (`get_article` or fetch) and the current top 3 results for its main search. Find what is stale: old years, outdated prices or tools, a slower answer than the results above it, missing subtopics.
4. Write the refresh as a list of edits (old, new) plus a new intro sentence with the current year only where the content is truly updated.
5. If Distribb has a `declining_page` optimization for the post that passes the stale-rewrite check (ground rules), show its before and after (`get_optimization`); on yes, `review_optimization` with `action: "approve"`, then `publish_optimization` when it is ready. Otherwise on yes, `update_article` with `sync: true`.

## Output
- Table: post | clicks before > now | position before > now | what is stale.
- The edits for each post.
