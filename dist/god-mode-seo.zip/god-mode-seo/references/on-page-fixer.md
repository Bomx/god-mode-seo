# on-page-fixer: exact edits, page by page

## Steps
1. Get the page: the URL the user gives, or the 5 pages with `striking_distance: true` and the most impressions from `search_console_performance`.
2. Its searches: `top_queries` from any `list_optimizations` entry for the page, otherwise the site's top queries on its topic.
3. Read the page (`get_article` or fetch) and the top 3 results for its main search (web search, then fetch).
4. Check, in this order: the main search in the title and H1; the answer in the first two or three sentences; subtopics the top results cover that the page skips; thin or outdated sections (old years, dead tools, old prices); internal links to and from the pillar page; image alt text.
5. Write each fix as old text and new text, with the section it belongs to.
6. If Distribb already has an optimization for this page, show its before and after (`get_optimization`) as the alternative.

## Output
- One sentence: the single biggest reason the page sits where it does.
- Numbered edits: section | old | new | why.
- On yes: `update_article` (`sync: true`) for Distribb articles, or `review_optimization` approve then `publish_optimization`. Otherwise the user pastes the edits.
