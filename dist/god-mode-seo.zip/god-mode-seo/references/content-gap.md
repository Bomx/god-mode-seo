# content-gap: what rivals cover and you skip

## Steps
1. Get the topic: a keyword, or a page of theirs (then its main search from `list_optimizations` or Search Console).
2. Web search it and read the top 5 results: list their H2s, the questions they answer and the entities they name.
3. Read the user's page (`get_article` or fetch) and their other articles' titles (`list_articles`).
4. Two gap lists:
   - **Missing on this page:** subtopics 3 or more of the top 5 cover that the page does not.
   - **Missing pages:** topics the rivals have a whole page on that the site has none for. Check volume with `keyword_research`.
5. If competitors are set in `get_project`, give each gap the rival that covers it best.

## Output
- One sentence: the biggest gap.
- Table 1: subtopic | covered by (how many of the top 5) | where it goes on the page.
- Table 2: missing page | search volume | difficulty | rival with that page.
- Next actions: on-page-fixer for table 1, content-engine for table 2.
