# robots-checker: robots, canonicals, sitemap

## Steps
1. Fetch `https://<site>/robots.txt` (site from `get_project`). Without a fetch tool, ask the user to paste it.
2. List every Disallow rule and test the 20 pages with the most clicks (`search_console_performance`, `days: 28`) against them. Any important page blocked is a critical issue.
3. Find the sitemap (`sitemap_url` from `get_project`, or the Sitemap line in robots.txt). Fetch it (and its child sitemaps). Check the 20 top pages are listed, and fetch up to 20 sitemap URLs to confirm they return 200 and are not redirects or noindex.
4. Fetch the 10 top pages and read the canonical tag (should point to itself unless on purpose) and any meta robots noindex.

## Output
- One sentence: critical issues first, or "no blocking issues".
- Table: check | result | pages affected | fix.
- A corrected robots.txt as a diff when rules need changing, and the exact tag changes for canonicals.
