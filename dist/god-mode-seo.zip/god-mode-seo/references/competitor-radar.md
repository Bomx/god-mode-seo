# competitor-radar: your closest rivals, week by week

## Steps
1. Read the rivals from `get_project` (`settings.competitors`). If there are none, ask for 3 to 5 competitor domains.
2. Pick the searches: from `search_console_performance` (`days: 28, limit: 200`) take the 10 non-brand queries with the most impressions where the user ranks in the top 30.
3. For each query, run a live web search and record the position of the user's domain and of each rival in the top 10 (write "not in top 10" when absent). Note the country you searched from: results change by location.
4. Call `ai_visibility_report` with `view: competitors` for citations in AI answers: you, each rival, and the other domains AI leans on.
5. Compare with the last snapshot:
   - In Claude Code, read and write `seo-snapshots/competitor-radar-YYYY-MM-DD.md` in the project folder.
   - In Claude.ai, ask the user to paste last week's table, and end with this week's table in a block they can save.

## Output
- One sentence: who gained and who lost since the last snapshot (or "first snapshot" when there is none).
- Table: query | you | rival 1 | rival 2 | ... with arrows for changes.
- AI citations: you vs each rival.
- Next actions: content-gap on the queries where a rival outranks you, mention-tracker for the AI side.
