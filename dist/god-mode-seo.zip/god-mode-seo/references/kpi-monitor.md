# kpi-monitor: weekly winners and losers

## Steps
1. `search_console_performance` with `days: 7` and `days: 14` (limit 1000). Previous week by the two-call calculation. Say the last 2 to 3 days are incomplete.
2. Totals: clicks, impressions, CTR, position, this week vs last.
3. The 5 pages and 5 searches that gained the most clicks, and the 5 that lost the most.
4. `backlinks_status` (links received and verified) and `ai_visibility_report` summary (score, engines citing you). To show change, compare with last week's report: in Claude Code read and write `seo-snapshots/kpi-monitor-YYYY-MM-DD.md`; in Claude.ai ask the user to paste last week's numbers.
5. What shipped: `list_articles` with status Published and `scheduled_after` a week ago, and optimizations published this week from `list_optimizations`.

## Output
- One sentence: the week in numbers and its biggest mover.
- KPI table: metric | this week | last week | change.
- Winners and losers tables, then what shipped.
- Offer to run it every Monday (Claude Code: a scheduled task; Claude.ai: ask each week).
