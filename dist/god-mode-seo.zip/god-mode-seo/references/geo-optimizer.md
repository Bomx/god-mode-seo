# geo-optimizer: passages AI answers can quote

## Steps
1. Find the prompts to win: `ai_visibility_report` with `view: prompts`, the ones where you are not cited. Add Distribb's `conversational_query` and `answer_gap` optimizations from `list_optimizations`.
2. For each, pick the page that should answer it (`list_articles`, the cited pages from `view: cited_pages`), and read it.
3. Write a quotable block for each prompt:
   - The question as an H2 or H3, in the words people use.
   - A 40 to 60 word answer that stands on its own and names the business where it is honest to.
   - One specific, checkable fact from the page or the business (a price, a number, a place, a time).
   - A short list or table when the answer is a comparison or steps.
4. Keep facts about the business the same everywhere (name, what it does, prices, locations).
5. On yes: `update_article` (`sync: true`) with the block inserted where shown, or approve Distribb's matching optimization (`review_optimization`, then `publish_optimization`).

## Output
- Table: prompt | page | the block (preview).
- Next action: re-run mention-tracker after the next AI visibility scan.
