# vitals-fixer: the speed fix to ship first

The connector has no speed data, so this skill reads Google's PageSpeed Insights.

## Steps
1. Pick the pages: the 5 pages with the most clicks in `search_console_performance` (`days: 28`).
2. For each, fetch `https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=<URL>&strategy=mobile&category=performance` (URL-encoded). Without a fetch tool, ask the user to run pagespeed.web.dev and paste the results.
3. Read the field data first (`loadingExperience`: LCP, INP, CLS at the 75th percentile, and its category). Use the lab data (`lighthouseResult.audits` with savings) for the causes. Thresholds for good: LCP 2.5 s or less, INP 200 ms or less, CLS 0.1 or less.
4. Group the causes across pages (for example "hero image not preloaded" on 4 of 5 pages) and rank them by pages affected x the savings PageSpeed reports.
5. Write the fix for the site's platform (from `get_project`, `setup.website.platform`): WordPress, Shopify, Webflow or custom.

## Output
- One sentence: which metric fails, on how many of the 5 pages, and the fix to ship first.
- Table: page | LCP | INP | CLS | status (from field data, or "lab only" when there is none).
- The ranked fix list with the exact steps for their platform.
