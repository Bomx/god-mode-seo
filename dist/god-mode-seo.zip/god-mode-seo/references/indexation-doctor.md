# indexation-doctor: pages Google never indexed

## Steps
1. All published URLs: `list_articles` with status Published (page through with `offset`).
2. Pages Google shows: `search_console_performance` with `days: 90, limit: 100`. A published page older than 3 weeks that is not in that list has little or no Google visibility: it is either not indexed or indexed and invisible. Say "not in the top 250 pages" rather than "zero impressions" on large sites.
3. Add Distribb's `crawl_proxy` optimizations from `list_optimizations` (pages with impressions but almost no clicks).
4. For up to 20 pages, oldest first, fetch each and check: noindex, canonical pointing elsewhere, redirects, in the sitemap or not, linked from any other article (search the HTML of the related articles with `get_article`), and thin content (under 300 words).
5. Say plainly that only Search Console's URL Inspection confirms indexing: ask the user to inspect the top 3 and request indexing after the fixes.

## Output
- Table: page | published | likely cause | fix.
- Next actions: internal-linker for orphans, robots-checker when several pages share the same block, refresh-finder for thin pages.
