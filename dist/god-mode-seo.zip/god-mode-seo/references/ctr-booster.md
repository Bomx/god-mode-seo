# ctr-booster: seen a lot, clicked a little

## Steps
1. `search_console_performance` with `days: 28, limit: 100`. Build your CTR benchmark by position band (cheat sheet).
2. Keep pages and queries in the top 10 with 100+ impressions and a CTR under half of their band's median (brand queries out). Add Distribb's `ctr_underperform` and `query_segment` optimizations from `list_optimizations` (`status: pending`, `limit: 25`). Note that searches with zero clicks never appear in `top_queries`, so the list under-counts.
3. Rank them by missed clicks = impressions x (band median CTR - their CTR). Label this an estimate from the site's own data.
4. For the top 10: read the current title and meta (from `list_articles`: Title, MetaDescription, MainKeyword; fetch the page when it is not a Distribb article). The connector does not link pages to queries: use the optimization's `top_queries` when there is one, otherwise the page's main keyword, and say which you used. Write one rewrite each, built on that search (60 characters for titles, 140 to 155 for descriptions, nothing the page does not deliver). Use meta-optimizer when the user wants 3 variants.
5. On yes, apply the exact title and meta the user saw: `update_article` with `{title, meta_description, sync: true}` for Distribb articles, otherwise the copy to paste. Use Distribb's own optimization only when it passes the stale-rewrite check (ground rules) and you showed its proposed title and meta.

## Output
- Table: page | main search | impressions | CTR vs band median | estimated missed clicks | new title.
- What you changed, and a reminder to run kpi-monitor in 14 days.
