# mention-tracker: where AI cites you, and where not

## Steps
1. Call `ai_visibility_report` with `view: summary`. If `has_data` is false, tell the user to run a scan from Distribb's AI visibility page and stop.
2. Call `view: prompts` (page through with `page` and `per_page: 10`) to list every tracked buyer prompt and whether you are cited.
3. Call `view: competitors`: citations for you and each rival, and `other_cited` (the domains AI answers lean on).
4. Call `view: cited_pages` to see which of your pages get cited.
5. For each prompt where you are missing, name the page on your site that should answer it (from `list_articles`), or "no page yet".

## Output
- One sentence: engines citing you out of the total, your share of voice, and the biggest gap.
- Table: prompt | cited? | page that should answer it.
- The 5 domains AI cites most that are not you: these are where to get listed or mentioned (roundups, directories, forums, videos).
- Next actions: geo-optimizer on the pages that should answer, content-engine for prompts with no page, keyword-finder for related searches.
