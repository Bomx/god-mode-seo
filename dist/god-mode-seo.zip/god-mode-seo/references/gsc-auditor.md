# gsc-auditor: why your clicks dropped

## Steps
1. Pick the project and check `setup.search_console.connected` with `get_project`. If it is not connected, send the connect link from `integrations_catalog` and stop.
2. Call `search_console_performance` twice: `days: 28, limit: 100` and `days: 56, limit: 100`. Ask the user first if they want another window (for example 7 vs 7 after an update).
3. Build the previous 28 days with the two-call calculation (cheat sheet) for the totals, every page and every query.
4. Clean the page list (drop or merge `#` and `?` URLs). Split the queries into brand and non-brand (`is_brand` only works on queries). A drop in brand searches is a demand problem, not an SEO one.
5. Rank pages by clicks lost, counting only pages with 100+ impressions in the previous period. For the top 10, name the cause with these rules:
   - **Ranking loss:** average position got worse by 1.5 or more.
   - **Less demand:** impressions down 20% or more while position moved less than 1. Fewer people searched, or a search feature took the space.
   - **Fewer clicks:** impressions within 20% and position within 1, CTR down. The result looks less clickable, or an AI Overview or other feature now sits above it.
   - **Mix shift:** impressions up 20% or more while CTR fell. The page now shows for broader, lower-intent searches: often not a real loss, say so.
   - **Gone:** the page is in the current list with 0 clicks, or missing from it. Check it still returns 200 and is indexable (indexation-doctor).
   - **Unclear:** none of the above. Say so rather than forcing a cause.
6. Do the same for the top 10 queries by clicks lost.
7. Call `list_optimizations` (`limit: 25`) and mark any page Distribb already flagged as `declining_page` or `cannibalisation` (match on `trigger_snapshot.article_url`), with its `signals.why` and the date it was flagged.

## Output
- One sentence: total clicks before and after with the % change, and how much of the loss sits in the top 3 pages.
- Table: page | clicks before > now | impressions before > now | position before > now | cause.
- Next actions, for example: refresh-finder for ranking losses, ctr-booster for click losses, cannibalization-finder when two pages share a query, indexation-doctor for gone pages.
