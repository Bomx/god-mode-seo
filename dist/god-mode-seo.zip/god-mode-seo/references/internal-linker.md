# internal-linker: links between your own pages

## Steps
1. List the site's pages: `list_articles` with status Published (page through with `offset`), plus the content pillars from `get_project`.
2. Pick the targets: pages with `striking_distance: true` in `search_console_performance` (`days: 28, limit: 100`), plus the content pillars (the pages that sell).
3. For each target, find 2 or 3 source pages on a related topic that do not link to it yet. Check with `get_article` that the target URL is not already in the source's HTML.
4. Choose the anchor from the target's main search (exact or a close variant) and the spot: quote the sentence in the source where the link fits naturally.
5. Also list Distribb's own `internal_link` and `link_boost` optimizations from `list_optimizations`.
6. On yes, apply one link at a time with `update_article` (content with the link added, `sync: true`), showing the changed sentence before and after. Distribb optimizations are applied with `review_optimization` then `publish_optimization`.

## Output
- Table (15 rows): source page | anchor text | target page | the sentence where it goes.
- Next actions: apply the plan, then kpi-monitor in 2 to 4 weeks on the targets.
