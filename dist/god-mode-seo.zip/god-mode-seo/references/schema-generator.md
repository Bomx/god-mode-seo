# schema-generator: rich result markup, ready to paste

## Steps
1. Get the page: `get_article` for a Distribb article, otherwise fetch the URL. Read `get_project` for the business name, website and location.
2. Pick the types that match what the page is: BlogPosting or Article for posts, Product or SoftwareApplication for product pages, LocalBusiness (with the address the business gave) for local pages, Organization and WebSite for the homepage, BreadcrumbList when the page has breadcrumbs. Use FAQPage only when the questions and answers are visible on the page, and say that Google shows FAQ rich results mainly for government and health sites.
3. Fill every field from the page or the project. Never add ratings, reviews, prices, dates or authors that are not on the page. Leave out a field rather than invent it.
4. Validate: check the JSON parses, required properties per type are present, and URLs are absolute.

## Output
- The JSON-LD in one `<script type="application/ld+json">` block.
- Where to paste it (theme header, SEO plugin, or the page's custom code), and the test to run: Google's Rich Results Test.
- On yes for a Distribb article, add it with `update_article` (`sync: true`). Some CMSs strip scripts from post content: if so, say to add it through the SEO plugin instead.
